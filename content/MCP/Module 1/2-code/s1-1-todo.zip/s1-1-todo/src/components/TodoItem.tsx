import { useState } from 'react';
import type { Todo } from '../types';

type Props = {
  todo: Todo;
  onToggle: (id: string) => void;
  onEdit: (id: string, text: string) => void;
  onDelete: (id: string) => void;
};

export default function TodoItem({ todo, onToggle, onEdit, onDelete }: Props) {
  // State tại chỗ: chỉ dòng này cần biết nó có đang sửa không
  const [isEditing, setIsEditing] = useState(false);
  // Bản nháp có chủ đích: chỉ sống trong lúc sửa, lưu xong mới đẩy lên cha
  const [draft, setDraft] = useState('');

  function startEdit() {
    setDraft(todo.text);
    setIsEditing(true);
  }

  function save() {
    const next = draft.trim();
    if (next) onEdit(todo.id, next);
    setIsEditing(false);
  }

  if (isEditing) {
    return (
      <li className="todo-item editing">
        <input
          aria-label={`Sửa: ${todo.text}`}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') save();
            if (e.key === 'Escape') setIsEditing(false);
          }}
          autoFocus
        />
        <button type="button" onClick={save}>Lưu</button>
        <button type="button" onClick={() => setIsEditing(false)}>Huỷ</button>
      </li>
    );
  }

  return (
    <li className="todo-item">
      <label>
        <input
          type="checkbox"
          checked={todo.done}
          onChange={() => onToggle(todo.id)}
        />
        <span className={todo.done ? 'done' : undefined}>{todo.text}</span>
      </label>
      <button type="button" onClick={startEdit}>Sửa</button>
      <button type="button" onClick={() => onDelete(todo.id)}>Xoá</button>
    </li>
  );
}
