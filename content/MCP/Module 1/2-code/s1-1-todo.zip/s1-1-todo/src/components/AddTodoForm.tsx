import { useState, type FormEvent } from 'react';

type Props = {
  onAdd: (text: string) => void; // callback: con gọi ngược lên cha
};

export default function AddTodoForm({ onAdd }: Props) {
  // State tại chỗ: chỉ form này cần biết chữ đang gõ
  const [text, setText] = useState('');
  const trimmed = text.trim(); // derived

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); // chặn trình duyệt tải lại trang
    if (!trimmed) return;
    onAdd(trimmed);
    setText(''); // controlled → xoá state là ô input trống
  }

  return (
    <form className="add-form" onSubmit={handleSubmit}>
      <label htmlFor="new-todo">Việc mới</label>
      <input
        id="new-todo"
        value={text}
        onChange={(e) => setText(e.target.value)}
        maxLength={80}
        placeholder="Ví dụ: tưới cây"
      />
      <button type="submit" disabled={!trimmed}>
        Thêm
      </button>
    </form>
  );
}
