import type { Filter } from '../types';

const OPTIONS: { value: Filter; label: string }[] = [
  { value: 'all', label: 'Tất cả' },
  { value: 'active', label: 'Đang làm' },
  { value: 'done', label: 'Đã xong' },
];

type Props = {
  filter: Filter;
  onFilterChange: (filter: Filter) => void;
};

export default function FilterBar({ filter, onFilterChange }: Props) {
  return (
    <div className="filter-bar" role="group" aria-label="Lọc việc">
      {OPTIONS.map((opt) => (
        <button
          key={opt.value}
          type="button"
          aria-pressed={filter === opt.value}
          onClick={() => onFilterChange(opt.value)}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}
