// Kiểu dữ liệu dùng chung cho cả app
export type Todo = {
  id: string; // id ổn định → dùng làm key
  text: string;
  done: boolean;
};

export type Filter = 'all' | 'active' | 'done';

export function matchesFilter(todo: Todo, filter: Filter): boolean {
  switch (filter) {
    case 'all':
      return true;
    case 'active':
      return !todo.done;
    case 'done':
      return todo.done;
  }
}
