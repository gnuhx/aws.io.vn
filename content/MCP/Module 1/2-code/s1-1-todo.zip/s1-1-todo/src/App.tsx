import { useState } from 'react';
import { matchesFilter, type Filter, type Todo } from './types';
import AddTodoForm from './components/AddTodoForm';
import FilterBar from './components/FilterBar';
import TodoList from './components/TodoList';

const initialTodos: Todo[] = [
  { id: 't1', text: 'Pha cà phê phin', done: true },
  { id: 't2', text: 'Đọc react.dev phần Learn', done: false },
  { id: 't3', text: 'Làm lab Todo', done: false },
];

export default function App() {
  // STATE: chỉ 2 thứ thật sự "nhớ" theo thời gian
  const [todos, setTodos] = useState<Todo[]>(initialTodos);
  const [filter, setFilter] = useState<Filter>('all');

  // DERIVED: tính lại mỗi lần render, KHÔNG để trong state
  const visibleTodos = todos.filter((t) => matchesFilter(t, filter));
  const remaining = todos.filter((t) => !t.done).length;

  function handleAdd(text: string) {
    setTodos((prev) => [...prev, { id: crypto.randomUUID(), text, done: false }]);
  }

  function handleToggle(id: string) {
    setTodos((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  }

  function handleEdit(id: string, text: string) {
    setTodos((prev) => prev.map((t) => (t.id === id ? { ...t, text } : t)));
  }

  function handleDelete(id: string) {
    setTodos((prev) => prev.filter((t) => t.id !== id));
  }

  return (
    <main className="app">
      <h1>Việc hôm nay</h1>
      <AddTodoForm onAdd={handleAdd} />
      <FilterBar filter={filter} onFilterChange={setFilter} />
      <TodoList
        todos={visibleTodos}
        onToggle={handleToggle}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
      <p className="footer">Còn lại: {remaining} việc</p>
    </main>
  );
}
