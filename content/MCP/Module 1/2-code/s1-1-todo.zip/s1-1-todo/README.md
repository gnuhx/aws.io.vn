# S1.1 — React cốt lõi · Lab Todo

Lab của Module 1, session S1.1 (roadmap MCP × Full-Stack AI): danh sách việc có thêm / sửa / xoá / lọc.

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # tsc kiểm tra kiểu + đóng gói
npm run lint
```

AC của session:
- Không có state trùng lặp — chỉ `todos` và `filter` là state; `visibleTodos`, `remaining` tính lúc render.
- `key` dùng id ổn định (`crypto.randomUUID()` lúc tạo todo), không dùng index.

```
src/
├── main.tsx              (giữ nguyên của Vite)
├── index.css
├── types.ts              Todo, Filter, matchesFilter()
├── App.tsx               state: todos, filter · derived: visibleTodos, remaining
└── components/
    ├── AddTodoForm.tsx   state tại chỗ: text
    ├── FilterBar.tsx     props: filter, onFilterChange
    ├── TodoList.tsx      map + key={todo.id}
    └── TodoItem.tsx      state tại chỗ: isEditing, draft
```
